public class MultilevelMain {
    public static void main(String[] args) { Manager m=new Manager("Arjun",40,8001,12); m.displayManager(); }
}
class Person { protected String name; protected int age; Person(String name,int age){this.name=name;this.age=age;} }
class Employee extends Person { private int employeeId; Employee(String name,int age,int employeeId){super(name,age);this.employeeId=employeeId;} protected int getEmployeeId(){return employeeId;} }
class Manager extends Employee { private int teamSize; Manager(String name,int age,int employeeId,int teamSize){super(name,age,employeeId);this.teamSize=teamSize;} void displayManager(){System.out.println("Name: "+name+", age: "+age+", employee ID: "+getEmployeeId()+", team size: "+teamSize);} }
